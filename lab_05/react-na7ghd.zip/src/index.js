import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div>
      <h1>Emily Ma</h1>
      <a href="mailto:ekma@usc.edu">ekma@usc.edu</a>
      <p id="favorite-color">Favorite color: cornflowerblue</p>

      <p>
        Favorite website:
        <a href="https://www.netflix.com" target="_blank">
          Netflix
        </a>
      </p>

      <div className="favorite-activity">
        <img
          src="https://www.boston.com/wp-content/uploads/2017/03/6bcc1880-56bd-11e2-884d-055e7b339a2f.jpg"
          alt="Paddle Tennis"
        />
        <p>Favorite activity: Paddle Tennis</p>
      </div>

      <ul className="class-list">
        <p>Fall 2023 Classes</p>
        <li>ITP 301: Front-End Web Development</li>
        <li>PSYC 305: Learning and Memory</li>
        <li>DSCI 250: Introduction to Data Informatics</li>
        <li>WRIT 340: Advanced Writing for Engineers</li>
      </ul>
    </div>
  </React.StrictMode>
);
