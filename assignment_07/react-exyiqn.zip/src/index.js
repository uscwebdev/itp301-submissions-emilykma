import React from 'react';
import { createRoot } from 'react-dom/client';
import Products from './products.js';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="header">
      <h1>S E P H O R A</h1>
    </div>

    <div id="body">
      <div id="title">
        <h1>My Basket</h1>
      </div>

      <div id="product-container">
        <Products
          src="https://img.cdn4dd.com/cdn-cgi/image/fit=contain,width=1200,height=672,format=auto/https://doordash-static.s3.amazonaws.com/media/photosV2/c7934a70-8cb5-4e9e-a462-524709121e62-retina-large.jpg"
          alt="Saie Lip Gloss"
          brand="Saie Beauty"
          product="Glossybounch High-Shine Hydrating Lip Gloss Oil"
          price="22"
        />

        <Products
          src="https://media.allure.com/photos/6216a7397887e544d95d4683/master/w_1280%2Cc_limit/rare%2520beauty%2520soft%2520pinch%2520liquid%2520blush.jpg"
          alt="Rare Beauty Tinted Lip Oil"
          brand="Rare Beauty by Selena Gomez"
          product="Soft Pinch Liquid Blush"
          price="20"
        />

        <Products
          src="https://m.media-amazon.com/images/I/41iXClhCvCL._AC_UF1000,1000_QL80_.jpg"
          alt="Soft Pop Blush"
          brand="Makeup By Mario"
          product="Soft Pop Plumping Blush Veil"
          price="30"
        />

        <Products
          src="https://beautyloversmexico.com/cdn/shop/products/31B9204D-0995-489A-85F6-BC7241E04A6F_1445x.jpg?v=1660924992"
          alt="Merit Bronzer"
          brand="Merit Beauty"
          product="Bronze Balm Sheer Scultping Bronzer"
          price="30"
        />

        <Products
          src="https://www.sephora.com/productimages/sku/s2407302-main-zoom.jpg"
          alt="Charlotte Tilbury Foundation"
          brand="Charlotte Tilburry"
          product="Holywood Flawless Filter"
          price="49"
        />

        <Products
          src="https://static.thcdn.com/images/large/original//productimg/1600/1600/13321778-4644896630144432.jpg"
          alt="Patrick Ta Contour"
          brand="PATRICK TA"
          product="Major Sculpt Creme Countour and Powder Duo"
          price="40"
        />
      </div>
    </div>

    <div id="footer">&copy; 2023 Sephora USA, Inc. All Rights Reserved.</div>
  </React.StrictMode>
);
