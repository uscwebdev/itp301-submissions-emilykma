import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import { Link as ScrollLink, Element } from 'react-scroll';
import Song from './Song';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>My Life Through Music</h1>
    <div id="container">
      <div id="header">
        <p>
          A collection of songs categorized into different genres and playlists.
          Browse through each playlist to get a sense of my most recent,
          favorite hits. Feel free to play a sample of each song to hear my
          Junior year through music!
        </p>
      </div>

      <div>
        <div id="sub-headings">
          <nav>
            <ScrollLink
              to="country"
              spy={true}
              smooth={true}
              duration={700}
              id="scrollCountry"
              className="scrollLink"
            >
              Country Road
            </ScrollLink>
            <ScrollLink
              to="dad"
              spy={true}
              smooth={true}
              duration={700}
              id="scrollDad"
              className="scrollLink"
            >
              Songs My Dad Would Approve Of
            </ScrollLink>
            <ScrollLink
              to="fishin"
              spy={true}
              smooth={true}
              duration={700}
              id="scrollFishin"
              className="scrollLink"
            >
              Gone Fishin'
            </ScrollLink>
          </nav>
        </div>

        <Element name="country" className="playlist-section">
          <h2>Country Road</h2>
        </Element>
        <div id="song-container">
          <Song
            src="https://upload.wikimedia.org/wikipedia/en/3/3d/MorganWallenMoreThanMyHometown.jpg"
            alt="More Than My Hometown"
            title="More Than My Hometown"
            artist="Morgan Wallen"
          />
          <Song
            src="https://i5.walmartimages.com/seo/Jon-Pardi-Mr-Saturday-Night-Vinyl_8ac136ed-03e8-4b10-a9ab-8fc48edc9618.272c647fb45a2cc23acb303276bd7a65.jpeg?odnHeight=640&odnWidth=640&odnBg=FFFFFF"
            alt="Mr. Saturday Night"
            title="Mr. Saturday Night"
            artist="Jon Pardi"
          />
          <Song
            src="https://upload.wikimedia.org/wikipedia/en/e/ef/Old_dominion_self_titled.jpg"
            alt="One Man Band"
            title="One Man Band"
            artist="Old Dominion"
          />
          <Song
            src="https://i.scdn.co/image/ab67616d0000b2730b11474886b9d16abdeaedf9"
            alt="Rock and a Hard Place"
            title="Rock and a Hard Place"
            artist="Bailey Zimmerman"
          />

          <Song
            src="https://upload.wikimedia.org/wikipedia/en/thumb/1/10/Dixieland_Delight_Alabama_cover.png/220px-Dixieland_Delight_Alabama_cover.png"
            alt="Dixieland Delight"
            title="Dixieland Delight"
            artist="Alabama"
          />
          <Song
            src="https://americanahighways.org/wp-content/uploads/2023/09/willie.jpg"
            alt="On the Road Again"
            title="On the Road Again"
            artist="Willie Nelson"
          />
          <Song
            src="https://i5.walmartimages.com/seo/Morgan-Wallen-If-I-Know-Me-CD_fa5c4644-0947-4bb8-a151-081b91809f0a_1.649707d4d775662de09b1360818892ce.jpeg?odnHeight=640&odnWidth=640&odnBg=FFFFFF"
            alt="Talkin' Tennessee"
            title="Talkin' Tennessee"
            artist="Morgan Wallen"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/a4/da/bd/a4dabd79-d3a6-5ef0-4f9c-95fbc4127bf3/JO_UTDH_cover.jpg/1200x1200bf-60.jpg"
            alt="Up There Down Here"
            title="Up There Down Here"
            artist="Jake Owen"
          />
          <Song
            src="https://i.scdn.co/image/ab67616d0000b273facd59568d0cfc3200296bb2"
            alt="Take Me Home, Country Roads"
            title="Take Me Home, Country Roads"
            artist="John Denver"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/c5/a8/b5/c5a8b504-f792-77eb-91a8-131be96b3a99/19UMGIM43785.rgb.jpg/1200x1200bb.jpg"
            alt="Heartache Medication"
            title="Heartache Medication"
            artist="Jon Pardi"
          />
          <Song
            src="https://i5.walmartimages.com/seo/Morgan-Wallen-One-Thing-At-A-Time-Country-2-CD-UMG_660b4a47-d105-4bec-9047-32ec5c9cbdbe.10686855eaf58893c8d0bc612cb05cf8.jpeg?odnHeight=640&odnWidth=640&odnBg=FFFFFF"
            alt="One Thing At a Time"
            title="One Thing At a Time"
            artist="Morgan Wallen"
          />
          <Song
            src="https://upload.wikimedia.org/wikipedia/en/d/d7/DariusRuckerFirstTime.jpg"
            alt="For the First Time"
            title="For the First Time"
            artist="Darius Rucker"
          />
        </div>

        <Element name="dad" className="playlist-section">
          <h2>Songs My Dad Would Approve Of</h2>
        </Element>
        <div id="song-container">
          <Song
            src="https://f4.bcbits.com/img/a1307838032_10.jpg"
            alt="Peach Fuzz"
            title="Peach Fuzz"
            artist="Caamp"
          />

          <Song
            src="https://i.scdn.co/image/ab67616d0000b273a5282e1178910f2102f2badb"
            alt="The Keys"
            title="The Keys"
            artist="Matt Duncan"
          />
          <Song
            src="https://i.discogs.com/f8EWpt24sQ8PJKTicpmquOWTYTYPDIMikE70revcvT4/rs:fit/g:sm/q:90/h:600/w:597/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTI1NTI5/NjctMTYyNTMwMjQy/MC05MDI0LmpwZWc.jpeg"
            alt="25 or 6 to 4"
            title="25 or 6 to 4"
            artist="Chicago"
          />
          <Song
            src="https://i.scdn.co/image/ab67616d0000b273e52a59a28efa4773dd2bfe1b"
            alt="The Chain"
            title="The Chain"
            artist="Fleetwood Mac"
          />
          <Song
            src="https://i.scdn.co/image/ab67616d0000b273b96c21e15c091eb98a6c88a4"
            alt="December, 1963"
            title="December, 1963"
            artist="The Four Seasons"
          />
          <Song
            src="https://i.scdn.co/image/ab67616d0000b2730c3a1b46b6b846dfdfbc6a7d"
            alt="Mary Jane's Last Dance"
            title="Mary Jane's Last Dance"
            artist="Tom Petty and the Heartbreakers"
          />
          <Song
            src="https://i1.sndcdn.com/artworks-fYQRfDqcxklx-0-t500x500.jpg"
            alt="Midnight Movies"
            title="Midnight Movies"
            artist="Saint Motel"
          />
          <Song
            src="https://i.ebayimg.com/images/g/k3wAAOSwADJkLfFJ/s-l1600.jpg"
            alt="Couldn't Get It Right"
            title="Couldn't Get It Right"
            artist="Climax Blues Band"
          />
          <Song
            src="https://upload.wikimedia.org/wikipedia/en/d/d2/The_Eagles_-_The_Eagles.jpeg"
            alt="Take It Easy"
            title="Take It Easy"
            artist="Eagles"
          />
          <Song
            src="https://m.media-amazon.com/images/I/81g1muvQWhL._UF1000,1000_QL80_.jpg"
            alt="Drift Away"
            title="Drift Away"
            artist="Uncle Kraker"
          />
          <Song
            src="https://i.scdn.co/image/ab67616d0000b273f875c8285d7f26a42baaa2a0"
            alt="She's So High"
            title="She's So High"
            artist="Tal Bachman"
          />
          <Song
            src="https://upload.wikimedia.org/wikipedia/en/c/c4/Jackie_Blue_-_Ozark_Mountain_Daredevils.jpg"
            alt="Jackie Blue"
            title="Jackie Blue"
            artist="The Ozark Mountain Dardevils"
          />
        </div>

        {/* 3rd Section */}
        <Element name="fishin" className="playlist-section">
          <h2>Gone Fishin'</h2>
        </Element>
        <div id="song-container">
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/7b/cc/cf/7bcccf54-8bf4-5e03-951e-c7582f35b09d/23UMGIM59938.rgb.jpg/1200x1200bb.jpg"
            alt="Dial Drunk"
            title="Dial Drunk"
            artist="Noah Kahan"
          />

          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music128/v4/b4/4f/0d/b44f0dbf-8dbb-a675-52d4-47276cd77701/cover.jpg/1200x1200bf-60.jpg"
            alt="Yellow Eyes"
            title="Yellow Eyes"
            artist="Rayland Baxter"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/cc/58/87/cc5887d6-e29f-88a5-2fd7-ba6c40f3bf53/0.jpg/600x600bf-60.jpg"
            alt="Dope On a Rope"
            title="Dope On a Rope"
            artist="The Growlers"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/c5/d2/e6/c5d2e675-92cf-88ab-d011-ebff55184353/617513807660_cover.jpg/600x600bf-60.jpg"
            alt="Orange Blossoms"
            title="Orange Blossoms"
            artist="GoldFord"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/34/12/78/34127801-ad2b-4469-4916-d661bba34a94/20UMGIM71875.rgb.jpg/1200x1200bb.jpg"
            alt="Starting Over"
            title="Starting Over"
            artist="Chris Stapleton"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music123/v4/2e/1b/bb/2e1bbb14-0890-0ef2-baf0-b5e216eb0aeb/192641337826_Cover.jpg/1200x1200bf-60.jpg"
            alt="Musta Been a Ghost"
            title="Musta Been a Ghost"
            artist="Proxima Parada"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/3d/65/e7/3d65e7fc-3d45-7487-946b-f371e7c597d5/dj.xzlimhgs.jpg/400x400cc.jpg"
            alt="Life in the City"
            title="Life in the City"
            artist="The Lumineers"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/42/42/d9/4242d9f7-f21d-76ab-3e21-1496aa3b3caa/093624848486.jpg/600x600bf-60.jpg"
            alt="Sarah's Place (feat. Noah Kahan)"
            title="Sarah's Place (feat. Noah Kahan)"
            artist="Zach Bryan"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/0f/cc/5f/0fcc5fda-4b7c-96da-d414-458745573a05/607396652532.png/1200x1200bb.jpg"
            alt="Annabel"
            title="Annabel"
            artist="49 Winchester"
          />
          <Song
            src="https://lastfm.freetls.fastly.net/i/u/ar0/84e708c86f0b4847a8e80e0e13494944.jpg"
            alt="It Aint Over Till Its Over"
            title="It Aint Over Till Its Over"
            artist="Lenny Kravitz"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music71/v4/4e/f7/6c/4ef76c5c-ebf7-62ed-4211-66812a1a0570/DT15yr_cvr.png/400x400bb.jpg"
            alt="Tomorrow"
            title="Tomorrow"
            artist="Shakey Graves"
          />
          <Song
            src="https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/5e/cf/8c/5ecf8c64-f3a0-80f6-c9ad-495c1058cd00/20UMGIM68914.rgb.jpg/600x600bf-60.jpg"
            alt="Lancaster Nights"
            title="Lancaster Nights"
            artist="Charlie Burg"
          />
        </div>
      </div>
    </div>
  </React.StrictMode>
);
