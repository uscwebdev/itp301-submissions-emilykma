import React from 'react';
import './index.css';

export default function Song(prop) {
  return (
    <div id="song">
      <div className="image">
        <img className="height-100" src={prop.src} alt={prop.alt} />
      </div>

      <p className="title">
        <strong>{prop.title}</strong>
      </p>

      <p className="artist">{prop.artist}</p>

      <p>(insert song sample from API)</p>
    </div>
  );
}
