import React from 'react';

export default function Comments(prop) {
  return (
    <div id="comment">
      <div className="profile">
        <img className="height-100" src={prop.src} alt={prop.alt} />
      </div>

      <p>
        <strong>{prop.username}</strong> posted on {prop.date}
      </p>

      <p>"{prop.content}"</p>
    </div>
  );
}
