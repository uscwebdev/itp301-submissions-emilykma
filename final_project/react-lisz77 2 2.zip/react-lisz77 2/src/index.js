import React, { useState } from 'react'; // Add useState to the import statement
import { createRoot } from 'react-dom/client';
import './index.css';
import { Link as ScrollLink, Element } from 'react-scroll';
import Song from './Song';
import Modal from './modal/Modal';
// import AddSongForm from './AddSongForm';

const App = () => {
  const [playlists, setPlaylists] = useState({
    smoothSoul: [], // Initialize an array for each of your playlists
    indieFolk: [],
    forDads: [],
    country: [],
    fishin: [],
    summer: [],
    // ... other playlists
  });

  // Function to handle adding songs
  const addSongToPlaylist = (playlistName, newSong) => {
    setPlaylists((prevPlaylists) => ({
      ...prevPlaylists,
      [playlistName]: [...prevPlaylists[playlistName], newSong],
    }));
  };

  return (
    <React.StrictMode>
      <h1>My Life Through Music</h1>
      <div id="container">
        <div id="header">
          <p>
            A collection of songs categorized into different genres and
            playlists. Browse through each playlist to get a sense of my
            favorite hits and hear my junior year through music! Click the pink
            '+'' button next to each playlist title to add a song to the
            playlist if you feel it fits! If you don't like a song in my
            playlists, feel free to click the 'x' button under each song to
            remove it (highly unrecommended - these are all hits!) Click on each
            playlist title to get a sense of the vibes of the playlist!
          </p>
        </div>

        <div>
          <div id="sub-headings">
            <nav>
              <ScrollLink
                to="RB"
                spy={true}
                smooth={true}
                duration={550}
                id="scrollRB"
                className="scrollLink"
              >
                Smooth Soul
              </ScrollLink>

              <ScrollLink
                to="alternative"
                spy={true}
                smooth={true}
                duration={750}
                id="scrollAlternative"
                className="scrollLink"
              >
                Indie Folk Revival
              </ScrollLink>

              <ScrollLink
                to="dad"
                spy={true}
                smooth={true}
                duration={950}
                id="scrollDad"
                className="scrollLink"
              >
                For Dads
              </ScrollLink>

              <ScrollLink
                to="country"
                spy={true}
                smooth={true}
                duration={1050}
                id="scrollCountry"
                className="scrollLink"
              >
                Country Road
              </ScrollLink>

              <ScrollLink
                to="fishin"
                spy={true}
                smooth={true}
                duration={1250}
                id="scrollFishin"
                className="scrollLink"
              >
                Gone Fishin'
              </ScrollLink>

              <ScrollLink
                to="summer"
                spy={true}
                smooth={true}
                duration={1450}
                id="scrollSummer"
                className="scrollLink"
              >
                Summer Anthems
              </ScrollLink>
            </nav>
          </div>

          {/* SOUL */}

          <Element name="RB" className="playlist-section">
            <Modal
              playlist="Smooth Soul"
              content="Enjoy this playlist consisting of some of my favorite R&B songs. Each song delivers a warm and soulful sound combining elements of R&B, indie rock, or electronic pop. This playlist is made to put you in a good mood and groove."
              onAddSong={(newSong) => addSongToPlaylist('smoothSoul', newSong)}
            />
            {/* {playlists.smoothSoul.map((song, index) => (
              <Song key={index} {...song} />
            ))} */}
          </Element>
          <div id="song-container">
            {/* ROW 1 */}
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/5e/cf/8c/5ecf8c64-f3a0-80f6-c9ad-495c1058cd00/20UMGIM68914.rgb.jpg/1200x1200bf-60.jpg"
              alt="Lancaster Nights"
              title="Lancaster Nights"
              artist="Charlie Burg"
              year="2020"
            />
            <Song
              src="https://f4.bcbits.com/img/a3268427232_10.jpg"
              alt="Good Kisser"
              title="Good Kisser"
              artist="Lake Street Drive"
              year="2018"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/c5/d2/e6/c5d2e675-92cf-88ab-d011-ebff55184353/617513807660_cover.jpg/600x600bf-60.jpg"
              alt="Orange Blossoms"
              title="Orange Blossoms"
              artist="GoldFord"
              year="2023"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music112/v4/d6/9f/12/d69f12a9-2c93-6db0-527b-ef577864e188/5054526226258_cover.jpg/600x600bf-60.jpg"
              alt="Atlas"
              title="Atlas"
              artist="The Dip"
              year="2019"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music123/v4/d4/fa/8f/d4fa8ff9-8f55-0568-503f-0b677e0f0458/artwork.jpg/1200x1200bf-60.jpg"
              alt="Praying for a Little Rain"
              title="Praying for a Little Rain"
              artist="Champagne Lane"
              year="2019"
            />
            {/* ROW 2 */}
            <Song
              src="https://f4.bcbits.com/img/a2382560972_10.jpg"
              alt="OP Jebediah"
              title="O.P. Jebediah"
              artist="The Dip"
              year="2019"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/ed/90/53/ed9053df-0476-f6aa-d7f2-8664fc589904/656605151465.jpg/600x600bf-60.jpg"
              alt="Texas Sun"
              title="Texas Sun"
              artist="Khrunangbin & Leon Bridges"
              year="2019"
            />
            <Song
              src="https://f4.bcbits.com/img/a1209581509_10.jpg"
              alt="Sun Go Down"
              title="Sun Go Down"
              artist="Fat Night"
              year="2015"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music123/v4/2e/1b/bb/2e1bbb14-0890-0ef2-baf0-b5e216eb0aeb/192641337826_Cover.jpg/1200x1200bf-60.jpg"
              alt="Musta Been a Ghost"
              title="Musta Been a Ghost"
              artist="Próxima Parada"
              year="2019"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/82/69/03/8269039e-2a0e-bd94-6018-80ea69799e66/859732630814_cover.jpg/1200x1200bf-60.jpg"
              alt="Highroad"
              title="Highroad"
              artist="Sir Woman"
              year="2019"
            />
            {/* ROW 3 */}
            <Song
              src="https://i.scdn.co/image/ab67616d0000b273c530fc0e97c1f04ec183df21"
              alt="Call Me"
              title="Call Me"
              artist="St. Paul & The Broken Bones"
              year="2014"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/8e/da/c4/8edac4db-68ab-058e-c73d-e693eb3f29b5/193436215787_01_img001.jpg/1200x1200bf-60.jpg"
              alt="Walk With Me"
              title="Walk With Me"
              artist="GoldFord"
              year="2020"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music112/v4/eb/09/b7/eb09b7d5-69db-0c46-de8b-11d35340b3aa/425.jpg/1200x1200bb.jpg"
              alt="Colors"
              title="Colors"
              artist="Black Pumas"
              year="2019"
            />

            <Song
              src="https://f4.bcbits.com/img/a0022249123_10.jpg"
              alt="1612"
              title="1612"
              artist="Vulfpeck"
              year="2014"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/38/6b/93/386b937e-ded5-3497-98a2-59d272d11015/666449673023_cover.jpg/1200x630bb.jpg"
              alt="When It Was Wrong"
              title="When It Was Wrong"
              artist="The California Honeydrops"
              year="2010"
            />
            {playlists.smoothSoul.map((song, index) => (
              <Song key={index} {...song} />
            ))}
          </div>

          <Element name="alternative" className="playlist-section">
            <Modal
              playlist="Indie Folk Revival"
              content="This playlist consists of a range of style, from a stripped-down, unplugged approach to lush harmonies and percussion-driven melodies. Regardless, each song reflects the feeling of the mystery of life, leaving you feeling either whole, or lost."
              onAddSong={(newSong) => addSongToPlaylist('indieFolk', newSong)}
            />
          </Element>
          <div id="song-container">
            {/* ROW 1 */}
            <Song
              src="https://f4.bcbits.com/img/a0352480261_10.jpg"
              alt="Life in the City"
              title="Life in the City"
              artist="The Lumineers"
              year="2019"
            />
            <Song
              src="https://i.scdn.co/image/ab67616d0000b27319ed71aa39d8e1d791aa9af6"
              alt="Sheep"
              title="Sheep"
              artist="Mt. Joy"
              year="2018"
            />

            <Song
              src="https://i.scdn.co/image/ab67616d0000b2736f95446c5dd8806464b836e6"
              alt="Candy"
              title="Candy"
              artist="Paolo Nutini"
              year="1989"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/7b/cc/cf/7bcccf54-8bf4-5e03-951e-c7582f35b09d/23UMGIM59938.rgb.jpg/1200x1200bb.jpg"
              alt="Paul Revere"
              title="Paul Revere"
              artist="Noah Kahan"
              year="2023"
            />
            <Song
              src="https://i1.sndcdn.com/artworks-bHgDSjgaACqP-0-t500x500.jpg"
              alt="Yellow Eyes"
              title="Yellow Eyes"
              artist="Rayland Baxter"
              year="2015"
            />
            {/* ROW 2 */}
            <Song
              src="https://i1.sndcdn.com/artworks-7CoZ31QD8jAz-0-t500x500.jpg"
              alt="Mountain Sound"
              title="Mountain Sound"
              artist="Of Monsters and Men"
              year="2011"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music/v4/ef/d7/a3/efd7a378-ed2a-b35a-0804-75f4e32de72b/888295058933.jpg/1200x630bb.jpg"
              alt="Pick a Place and Read"
              title="Pick a Place and Read"
              artist="Ezra Bell"
              year="2013"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/f4/51/99/f45199b6-9529-c884-110d-11d21ed67d8a/602547344403_1.jpg/600x600bf-60.jpg"
              alt="Little Lion Man"
              title="Little Lion Man"
              artist="Mumford & Sons"
              year="2009"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music118/v4/2f/3a/26/2f3a2633-d370-97ad-f7b9-62cb389e5068/075679872036.jpg/600x600bf-60.jpg"
              alt="Saturday Sun"
              title="Saturday Sun"
              artist="Vance Joy"
              year="2016"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/63/b1/74/63b174eb-845d-7ad1-dd2e-24d8e60fdeaa/193428577343_cover.jpg/1200x1200bb.jpg"
              alt="Pool House"
              title="Pool House"
              artist="The Backseat Lovers"
              year="2019"
            />
            {/* ROW 3 */}

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/56/66/79/56667945-1a14-d8d9-b0bb-d2cf8b110e6b/075679874504.jpg/600x600bf-60.jpg"
              alt="Hallucinoenics"
              title="Hallucinoenics"
              artist="Matt Maeson"
              year="2018"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music/v4/d7/1b/e9/d71be9a4-da25-70c2-956d-93a1e9280df5/Cover.jpg/600x600bf-60.jpg"
              alt="The Mtn Song"
              title="The Mtn Song"
              artist="Rayland Baxter"
              year="2012"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music118/v4/93/cf/3a/93cf3a98-2813-3ab7-a21c-71a20bc0e408/075679880390.jpg/600x600bf-60.jpg"
              alt="It's Called: Freefall"
              title="It's Called: Freefall"
              artist="Rainbow Kitten Surprise"
              year="2018"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music112/v4/5a/3f/8e/5a3f8ec5-be0d-580c-6f2e-8634121d5e68/22UM1IM01116.rgb.jpg/1200x1200bf-60.jpg"
              alt="Orange Juice"
              title="Orange Juice"
              artist="Noah Kahan"
              year="2023"
            />
            <Song
              src="https://i.scdn.co/image/ab67616d0000b27319ed71aa39d8e1d791aa9af6"
              alt="Dirty Love"
              title="Dirty Love"
              artist="Mt. Joy"
              year="2018"
            />
            {playlists.indieFolk.map((song, index) => (
              <Song key={index} {...song} />
            ))}
          </div>

          {/* FOR DADS */}
          <Element name="dad" className="playlist-section">
            <Modal
              playlist="For Dads"
              content="'For Dads' means exactly what it spells. Individuals who like vibing to the songs in this playlist either have an old soul, or simply enjoy good tunes. Guaranteed to put your dad in a better mood, you may want to play some of these hits for him the next time he's upset with you."
              onAddSong={(newSong) => addSongToPlaylist('forDads', newSong)}
            />
          </Element>
          <div id="song-container">
            <Song
              src="https://f4.bcbits.com/img/a1307838032_10.jpg"
              alt="Peach Fuzz"
              title="Peach Fuzz"
              artist="Caamp"
              year="2019"
            />
            <Song
              src="https://i.scdn.co/image/ab67616d0000b273a5282e1178910f2102f2badb"
              alt="The Keys"
              title="The Keys"
              artist="Matt Duncan"
              year="2013"
            />
            <Song
              src="https://i.discogs.com/f8EWpt24sQ8PJKTicpmquOWTYTYPDIMikE70revcvT4/rs:fit/g:sm/q:90/h:600/w:597/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTI1NTI5/NjctMTYyNTMwMjQy/MC05MDI0LmpwZWc.jpeg"
              alt="25 or 6 to 4"
              title="25 or 6 to 4"
              artist="Chicago"
              year="1970"
            />
            <Song
              src="https://i.scdn.co/image/ab67616d0000b273e52a59a28efa4773dd2bfe1b"
              alt="The Chain"
              title="The Chain"
              artist="Fleetwood Mac"
              year="1977"
            />
            <Song
              src="https://i.scdn.co/image/ab67616d0000b273b96c21e15c091eb98a6c88a4"
              alt="December, 1963"
              title="December, 1963"
              artist="The Four Seasons"
              year="1975"
            />
            <Song
              src="https://i.scdn.co/image/ab67616d0000b2730c3a1b46b6b846dfdfbc6a7d"
              alt="Mary Jane's Last Dance"
              title="Mary Jane's Last Dance"
              artist="Tom Petty and the Heartbreakers"
              year="1993"
            />
            <Song
              src="https://i1.sndcdn.com/artworks-fYQRfDqcxklx-0-t500x500.jpg"
              alt="Midnight Movies"
              title="Midnight Movies"
              artist="Saint Motel"
              year="2014"
            />
            <Song
              src="https://i.ebayimg.com/images/g/k3wAAOSwADJkLfFJ/s-l1600.jpg"
              alt="Couldn't Get It Right"
              title="Couldn't Get It Right"
              artist="Climax Blues Band"
              year="1976"
            />
            <Song
              src="https://upload.wikimedia.org/wikipedia/en/d/d2/The_Eagles_-_The_Eagles.jpeg"
              alt="Take It Easy"
              title="Take It Easy"
              artist="Eagles"
              year="1972"
            />
            <Song
              src="https://m.media-amazon.com/images/I/81g1muvQWhL._UF1000,1000_QL80_.jpg"
              alt="Drift Away"
              title="Drift Away"
              artist="Uncle Kraker"
              year="2003"
            />
            <Song
              src="https://upload.wikimedia.org/wikipedia/en/c/c4/Jackie_Blue_-_Ozark_Mountain_Daredevils.jpg"
              alt="Jackie Blue"
              title="Jackie Blue"
              artist="The Ozark Mountain Daredevils"
              year="1974"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/f0/c7/c8/f0c7c8f4-4319-d357-ddaf-566ef8e2194e/081227979379.jpg/1200x1200bb.jpg"
              alt="One of These Nights"
              title="One of These Nights"
              artist="Eagles"
              year="1975"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/8d/cf/29/8dcf296b-4e87-071e-8275-8fae029c57ed/14ULAIM00941.rgb.jpg/1200x1200bb.jpg"
              alt="Southern Nights"
              title="Southern Nights"
              artist="Glen Campbell"
              year="1977"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/22/3e/ed/223eedeb-3ad1-2bd8-c863-ab6fb39d658a/093624920137.jpg/600x600bf-60.jpg"
              alt="Dark Necessities"
              title="Dark Necessities"
              artist="Red Hot Chili Peppers"
              year="2016"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/e6/71/6a/e6716a69-cc2a-9327-9de1-8b32c77f40b6/886445621334.jpg/600x600bf-60.jpg"
              alt="Brown Eyed Girl"
              title="Brown Eyed Girl"
              artist="Van Morrison"
              year="1967"
            />
            {playlists.forDads.map((song, index) => (
              <Song key={index} {...song} />
            ))}
          </div>

          {/* COUNTRY */}

          <Element name="country" className="playlist-section">
            <Modal
              playlist="Country Road"
              content="As someone who despised country music a year ago, 19 year old me would be shocked to find this playlist making its way to this project. Regardless, this playlists contains hits that will persuade your country-hating friends to give the genre a try. With ranges from old classics to modern country, no one would dare call this playlist all hat and no cattle."
              onAddSong={(newSong) => addSongToPlaylist('country', newSong)}
            />
          </Element>
          <div id="song-container">
            <Song
              src="https://upload.wikimedia.org/wikipedia/en/3/3d/MorganWallenMoreThanMyHometown.jpg"
              alt="More Than My Hometown"
              title="More Than My Hometown"
              artist="Morgan Wallen"
              year="2020"
            />
            <Song
              src="https://i5.walmartimages.com/seo/Jon-Pardi-Mr-Saturday-Night-Vinyl_8ac136ed-03e8-4b10-a9ab-8fc48edc9618.272c647fb45a2cc23acb303276bd7a65.jpeg?odnHeight=640&odnWidth=640&odnBg=FFFFFF"
              alt="Mr. Saturday Night"
              title="Mr. Saturday Night"
              artist="Jon Pardi"
              year="2022"
            />
            <Song
              src="https://upload.wikimedia.org/wikipedia/en/e/ef/Old_dominion_self_titled.jpg"
              alt="One Man Band"
              title="One Man Band"
              artist="Old Dominion"
              year="2019"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/38/6a/b2/386ab229-da3e-35ad-27b8-0aca4546dbb3/720665657271_Cover.jpg/1200x1200bf-60.jpg"
              alt="Gettin' By"
              title="Gettin' By"
              artist="Flatland Cavalry"
              year="2021"
            />
            <Song
              src="https://upload.wikimedia.org/wikipedia/en/thumb/1/10/Dixieland_Delight_Alabama_cover.png/220px-Dixieland_Delight_Alabama_cover.png"
              alt="Dixieland Delight"
              title="Dixieland Delight"
              artist="Alabama"
              year="1983"
            />
            <Song
              src="https://americanahighways.org/wp-content/uploads/2023/09/willie.jpg"
              alt="On the Road Again"
              title="On the Road Again"
              artist="Willie Nelson"
              year="1980"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/ea/00/8b/ea008b95-8318-b906-0995-4f8295bf5e4b/13UMGIM60578.rgb.jpg/486x486bb.png"
              alt="Ramblin' Man"
              title="Ramblin' Man"
              artist="The Allman Brothers Band"
              year="1973"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/ef/b2/ad/efb2ad81-9784-f4f4-a0c9-6cee32362bfa/067003034951.png/1200x630bb.jpg"
              alt="Wagon Wheel"
              title="Wagon Wheel"
              artist="Old Crow Medicine Show"
              year="2004"
            />
            <Song
              src="https://i5.walmartimages.com/seo/Morgan-Wallen-If-I-Know-Me-CD_fa5c4644-0947-4bb8-a151-081b91809f0a_1.649707d4d775662de09b1360818892ce.jpeg?odnHeight=640&odnWidth=640&odnBg=FFFFFF"
              alt="Talkin' Tennessee"
              title="Talkin' Tennessee"
              artist="Morgan Wallen"
              year="2018"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/c5/a8/b5/c5a8b504-f792-77eb-91a8-131be96b3a99/19UMGIM43785.rgb.jpg/1200x1200bb.jpg"
              alt="Heartache Medication"
              title="Heartache Medication"
              artist="Jon Pardi"
              year="2019"
            />
            <Song
              src="https://i5.walmartimages.com/seo/Morgan-Wallen-One-Thing-At-A-Time-Country-2-CD-UMG_660b4a47-d105-4bec-9047-32ec5c9cbdbe.10686855eaf58893c8d0bc612cb05cf8.jpeg?odnHeight=640&odnWidth=640&odnBg=FFFFFF"
              alt="One Thing At a Time"
              title="One Thing At a Time"
              artist="Morgan Wallen"
              year="2023"
            />
            <Song
              src="https://upload.wikimedia.org/wikipedia/en/d/d7/DariusRuckerFirstTime.jpg"
              alt="For the First Time"
              title="For the First Time"
              artist="Darius Rucker"
              year="2017"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/4d/67/1e/4d671eec-8c29-4f7d-90f8-d0c2a6b0e5d3/196871363129.jpg/1200x1200bf-60.jpg"
              alt="Mad Man"
              title="Mad Man"
              artist="Eddie Flint"
              year="2023"
            />
            <Song
              src="https://americanahighways.org/wp-content/uploads/2021/10/CWGalbum_front_jpeg_540x.jpeg"
              alt="Strong"
              title="Strong"
              artist="Charles Wesley Goodwin"
              year="2021"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/e8/1b/44/e81b44cc-9a2f-9960-1a99-e6eb4389a113/08UMGIM03456.rgb.jpg/1200x1200bb.jpg"
              alt="Should've Been a Cowboy"
              title="Should've Been a Cowboy"
              artist="Toby Keith"
              year="1993"
            />
            {playlists.country.map((song, index) => (
              <Song key={index} {...song} />
            ))}
          </div>

          {/* GONE FISHIN */}
          <Element name="fishin" className="playlist-section">
            <Modal
              playlist="Gone Fishin'"
              content="Feel free to listen to this playlist on your next fishing trip, watching little fishies flock to your line to join in on the happy tunes. Majority falling within the alternative genre, this playlist finds its light-heartedness in a diversity of sounds from indie, to folk, to country, to soft rock. Regardless, you are guaranteed to resonate with the sounds of a strumming guitar."
              onAddSong={(newSong) => addSongToPlaylist('fishin', newSong)}
            />
            {playlists.fishin.map((song, index) => (
              <Song key={index} {...song} />
            ))}
          </Element>
          <div id="song-container">
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/7b/cc/cf/7bcccf54-8bf4-5e03-951e-c7582f35b09d/23UMGIM59938.rgb.jpg/1200x1200bb.jpg"
              alt="Dial Drunk"
              title="Dial Drunk"
              artist="Noah Kahan"
              year="2023"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music71/v4/4e/f7/6c/4ef76c5c-ebf7-62ed-4211-66812a1a0570/DT15yr_cvr.png/400x400bb.jpg"
              alt="Tomorrow"
              title="Tomorrow"
              artist="Shakey Graves"
              year="2014"
            />
            <Song
              src="https://i.scdn.co/image/ab67616d0000b2733efcd243aaa5638f55318f91"
              alt="Bad Moon Rising"
              title="Bad Moon Rising"
              artist="Creedence Clearwater Revival"
              year="1969"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/42/42/d9/4242d9f7-f21d-76ab-3e21-1496aa3b3caa/093624848486.jpg/600x600bf-60.jpg"
              alt="Sarah's Place (feat. Noah Kahan)"
              title="Sarah's Place (feat. Noah Kahan)"
              artist="Zach Bryan"
              year="2020"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/0f/cc/5f/0fcc5fda-4b7c-96da-d414-458745573a05/607396652532.png/1200x1200bb.jpg"
              alt="Annabel"
              title="Annabel"
              artist="49 Winchester"
              year="2022"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music114/v4/13/ee/b7/13eeb76d-76ba-8a33-b2eb-eff11f17a259/05033197263427.rgb.jpg/486x486bb.png"
              alt="Maybe Tomorrow"
              title="Maybe Tomorrow"
              artist="Stereophonics"
              year="2003"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/21/4c/0e/214c0ec0-6b0e-dbe6-1705-388cb87b4381/886446539829.jpg/600x600bf-60.jpg"
              alt="Feathered Indians"
              title="Feathered Indians"
              artist="Tyler Childers"
              year="2017"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/34/12/78/34127801-ad2b-4469-4916-d661bba34a94/20UMGIM71875.rgb.jpg/1200x1200bb.jpg"
              alt="Starting Over"
              title="Starting Over"
              artist="Chris Stapleton"
              year="2020"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/4c/ba/03/4cba03fd-3bb9-b7ad-1dc0-e6bd2e29585d/745099189266.jpg/486x486bb.png"
              alt="This Charming Man"
              title="This Charming Man"
              artist="The Smiths"
              year="1983"
            />
            <Song
              src="https://f4.bcbits.com/img/a1993776623_65"
              alt="Happy Instead"
              title="Happy Instead"
              artist="Zach Bryan"
              year="2018"
            />
            <Song
              src="https://i.discogs.com/mPudrxxXuvrpHGyk36AMHIZKPOWUSxe7FBWD8K_d52M/rs:fit/g:sm/q:90/h:600/w:600/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTIwNzky/NzAtMTUxMTY0NDE0/Ny05MzQ1LmpwZWc.jpeg"
              alt="Who'll Stop the Rain"
              title="Who'll Stop the Rain"
              artist="Creedence Clearwater Revival"
              year="1970"
            />
            <Song
              src="https://images.genius.com/74d5e3e238455d09608048878974cc08.640x640x1.jpg"
              alt="Moonlight"
              title="Moonlight"
              artist="KAWALA"
              year="2018"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/65/12/41/6512414c-08cf-fddf-e4bb-4ee5bb032181/197189660139.jpg/1200x1200bf-60.jpg"
              alt="Time Shrinks"
              title="Time Shrinks"
              artist="Arcy Drive"
              year="2019"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/46/2d/21/462d21e0-0e34-0ce1-6308-f775b650d0e3/193436336543_idksacFINAL.jpg/1200x1200bb.jpg"
              alt="Idk Shit About Cars"
              title="Idk Shit About Cars"
              artist="Evan Honer"
              year="2021"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music116/v4/a9/4d/65/a94d65a3-6a45-f903-1cec-e56c1de27e8d/886449563654.jpg/600x600bf-60.jpg"
              alt="Give Up Baby Go"
              title="Give Up Baby Go"
              artist="Peach Pit"
              year="2020"
            />

            {playlists.fishin.map((song, index) => (
              <Song key={index} {...song} />
            ))}
          </div>

          {/* SUMMER */}
          <Element name="summer" className="playlist-section">
            <Modal
              playlist="Summer Anthems"
              content="These anthems stood out as front-runners of my summer in Long Island. Considering the vast range in sounds from house, to pop, to reggae and beyond, this playlist lacks cohesiveness. But the one thing all of these songs share in common is that they emit feelings of the sun beaming down on you. If you are interested in melodic songwriting, killer riffs, or electric beats, be sure to give this playlist a play on your next scenic drive with the windows down."
              onAddSong={(newSong) => addSongToPlaylist('summer', newSong)}
            />
          </Element>
          <div id="song-container">
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/ad/5c/88/ad5c888b-3add-e6d9-0561-a96b42b75de8/886448230168.jpg/1200x630bb.jpg"
              alt="Babydoll"
              title="Babydoll"
              artist="Dominic Fike"
              year="2019"
            />
            <Song
              src="https://lastfm.freetls.fastly.net/i/u/ar0/31175bafa9909e25577f2d64b1ad02b6.jpg"
              alt="Dope On a Rope"
              title="Dope On a Rope"
              artist="The Growlers"
              year="2016"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music125/v4/6d/0f/29/6d0f293d-01c9-10bf-c685-3f76536287ad/886447427453.jpg/1200x1200bb.jpg"
              alt="Sundress"
              title="Sundress"
              artist="A$AP Rocky"
              year="2018"
            />

            <Song
              src="https://lastfm.freetls.fastly.net/i/u/ar0/58669d5e97b3f2b09c36d5671802f89d.jpg"
              alt="Dance, Baby!"
              title="Dance, Baby!"
              artist="boy pablo"
              year="2017"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music/v4/6d/29/36/6d293611-2e7b-d52a-b39c-42b04c2d62c7/743212493122.jpg/1200x1200bf-60.jpg"
              alt="Sunny"
              title="Sunny"
              artist="Boney M."
              year="1976"
            />

            {/* ROW 2 */}
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music111/v4/83/b8/3f/83b83fbf-1026-52ac-d75f-a50390fdb34a/886446301198.jpg/1200x1200bb.jpg"
              alt="Way It Goes"
              title="Way It Goes"
              artist="Hippo Campus"
              year="2017"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/75/d9/ee/75d9eeb1-276a-6871-5656-48c6492d2a47/cover.jpg/1200x1200bb.jpg"
              alt="Relax My Eyes"
              title="Relax My Eyes"
              artist="ANOTR & Abel Balder"
              year="2020"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/2b/c4/c9/2bc4c9d4-3bc6-ab13-3f71-df0b89b173de/886448022213.jpg/1200x1200bb.jpg"
              alt="Golden"
              title="Golden"
              artist="Harry Styles"
              year="2019"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music114/v4/36/43/c3/3643c315-2caa-4718-05d1-5e3451763272/859711235696_cover.jpg/600x600bf-60.jpg"
              alt="Yellow Mellow"
              title="Yellow Mellow"
              artist="Ocean Alley"
              year="2018"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music/v4/17/a0/58/17a0585a-be85-3560-a756-2aa11e3583c9/5099908727053_1470x1470_300dpi.jpg/600x600bf-60.jpg"
              alt="Right Down the Line"
              title="Right Down the Line"
              artist="Gerry Rafferty"
              year="1978"
            />

            {/* ROW 3 */}
            <Song
              src="https://lastfm.freetls.fastly.net/i/u/ar0/84e708c86f0b4847a8e80e0e13494944.jpg"
              alt="It Ain't Over 'Till It's Over"
              title="It Ain't Over 'Till It's Over"
              artist="Lenny Kravitz"
              year="1998"
            />
            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music126/v4/ff/6d/94/ff6d948d-ca8c-5c88-a0ab-e9913377269c/653738041823_Cover.jpg/1200x1200bf-60.jpg"
              alt="The Difference (feat. Toro y Moi)"
              title="The Difference (feat. Toro y Moi)"
              artist="Flume"
              year="2020"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music124/v4/98/a5/7c/98a57c6d-c857-90bb-5835-fdd60699bf05/06UMGIM09147.rgb.jpg/486x486bb.png"
              alt="Come On Eileen"
              title="Come On Eileen"
              artist="Dexys Midnight Runners"
              year="1982"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music122/v4/94/a0/10/94a01075-8125-c028-cd36-863cf97c873a/196589446497.jpg/600x600bf-60.jpg"
              alt="MAN ON THE MOON"
              title="MAN ON THE MOON"
              artist="BROCKHAMPTON"
              year="2022"
            />

            <Song
              src="https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/a8/2e/b4/a82eb490-f30a-a321-461a-0383c88fec95/15UMGIM23316.rgb.jpg/600x600bf-60.jpg"
              alt="The Less I Know The Better"
              title="The Less I Know The Better"
              artist="Tame Impala"
              year="2015"
            />
            {playlists.summer.map((song, index) => (
              <Song key={index} {...song} />
            ))}
          </div>
        </div>
      </div>

      <div id="footer">Emily Ma &copy; 2023</div>
    </React.StrictMode>
  );
};

const root = createRoot(document.querySelector('#root'));
root.render(<App />);
