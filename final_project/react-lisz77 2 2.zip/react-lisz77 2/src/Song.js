import React from 'react';
import './index.css';
import { useState } from 'react';

export default function Song(prop) {
  // Remove Song
  const [showElements, setShowElements] = useState(true);

  const removeElements = () => {
    setShowElements(false);
  };

  if (!showElements) {
    return null; // this will not render the component at all if showElements is false; fixes margin spacing between removed Songs
  }

  return (
    <div id="song">
      <div style={{ display: showElements ? 'block' : 'none' }}>
        <div className="thumbnails">
          <img className="height-100" src={prop.src} alt={prop.alt} />
          <div class="overlay">
            {/* <img
              className="playimg"
              src="../img/play.png"
              alt="play icon"
              style={{ color: 'red', fontSize: '24px' }}
            /> */}
          </div>
        </div>

        <p className="title">
          <strong>{prop.title}</strong>
          {showElements && (
            <button onClick={removeElements} className="remove-button">
              X
            </button>
          )}
        </p>

        <p className="artist">{prop.artist}</p>

        <p className="year">{prop.year}</p>
      </div>
    </div>
  );
}
