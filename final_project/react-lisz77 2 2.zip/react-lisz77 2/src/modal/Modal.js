import React, { useState } from 'react';
import './Modal.css';
import AddSongForm from '../AddSongForm'; // Adjust the relative path as necessary

export default function Modal(prop) {
  const [modal, setModal] = useState(false);

  const toggleModal = () => {
    setModal(!modal);
  };

  const [showAddSongForm, setShowAddSongForm] = useState(false);

  const handleSaveSong = (song) => {
    // Function to save the new song to the playlist
    prop.onAddSong(song); // This will need to be passed as a prop to Modal
    setShowAddSongForm(false); // Close the form
  };

  // prevents user from moving screen while modal is open
  // if(modal) {
  //   document.body.classList.add('active-modal')
  // } else {
  //   document.body.classList.remove('active-modal')
  // }

  return (
    <>
      <button onClick={toggleModal} className="no-btn-style">
        {/* playlist header */}
        {prop.playlist}
      </button>

      {/* inside the modal/popup */}
      {modal && (
        <div className="modal">
          <div onClick={toggleModal} className="mod-overlay"></div>
          <div className="modal-content">
            <h2 className="modal-header">{prop.playlist}</h2>
            <p className="modal-p">{prop.content}</p>
            <button className="close-modal" onClick={toggleModal}>
              X
            </button>
          </div>
        </div>
      )}

      <div className="playlist-header">
        <button
          className="add-song-btn"
          onClick={() => setShowAddSongForm(true)}
        >
          +
        </button>
      </div>
      {showAddSongForm && <AddSongForm onSave={handleSaveSong} />}
    </>
  );
}
