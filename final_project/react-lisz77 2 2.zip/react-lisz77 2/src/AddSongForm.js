import React, { useState } from 'react';
import './AddSongForm.css'; // You will need to create this CSS file to style the form

export default function AddSongForm({ onSave }) {
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [year, setYear] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [imageAlt, setImageAlt] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    onSave({
      title,
      artist,
      year,
      src: imageUrl,
      alt: imageAlt,
    });
    // Clear the form fields
    setTitle('');
    setArtist('');
    setYear('');
    setImageUrl('');
    setImageAlt('');
  };

  return (
    <form onSubmit={handleSubmit} className="add-song-form">
      <input
        type="text"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Song title"
        required
      />
      <input
        type="text"
        value={artist}
        onChange={(e) => setArtist(e.target.value)}
        placeholder="Artist"
        required
      />
      <input
        type="text"
        value={year}
        onChange={(e) => setYear(e.target.value)}
        placeholder="Year"
        required
      />
      <input
        type="text"
        value={imageUrl}
        onChange={(e) => setImageUrl(e.target.value)}
        placeholder="Image URL"
        required
      />
      <input
        type="text"
        value={imageAlt}
        onChange={(e) => setImageAlt(e.target.value)}
        placeholder="Image alt text"
        required
      />
      <button type="submit">Save Song</button>
    </form>
  );
}
