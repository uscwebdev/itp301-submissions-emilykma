import React from 'react';
import { useState } from 'react';
import './index.css';
import { createRoot } from 'react-dom/client';

const root = createRoot(document.querySelector('#root'));

function FaveArtists() {
  const [src, setSrc] = useState(
    'https://i0.wp.com/www.beyondthestagemagazine.com/wp-content/uploads/2020/10/harry-styles-ugh-scaled.jpg'
  );

  const [alt, setAlt] = useState('Harry Styles');

  const [caption, setCaption] = useState('Harry Styles');

  function handleImgChange(newSrc, newAlt, newCaption) {
    setSrc(newSrc);
    setAlt(newAlt);
    setCaption(newCaption);
  }

  const imageButtons = [
    {
      buttonNum: 'Image 1',
      src: 'https://i0.wp.com/www.beyondthestagemagazine.com/wp-content/uploads/2020/10/harry-styles-ugh-scaled.jpg',
      alt: 'Harry Styles',
      caption: 'Harry Styles',
    },
    {
      buttonNum: 'Image 2',
      src: 'https://www.redlightmanagement.com/wp-content/uploads/2022/08/image002-1-682x1024.jpg',
      alt: 'Rayland Baxter',
      caption: 'Rayland Baxter',
    },
    {
      buttonNum: 'Image 3',
      src: 'https://littlewanderbook.com/wp-content/uploads/2015/10/Jack-Johnson.jpg',
      alt: 'Jack Johnson',
      caption: 'Jack Johnson',
    },
    {
      buttonNum: 'Image 4',
      src: 'https://townsquare.media/site/204/files/2023/06/attachment-morgan-wallen-2023-concert-dates-cleared-from-vocal-rest.jpg',
      alt: 'Morgan Wallen',
      caption: 'Morgan Wallen',
    },
    {
      buttonNum: 'Image 5',
      src: 'https://media.wnyc.org/i/800/0/l/85/2022/12/LeadPhoto.JPG',
      alt: 'Noah Kahan',
      caption: 'Noah Kahan',
    },
  ];

  return (
    <React.StrictMode>
      <div className="App">
        <div id="main">
          <div id="Title">
            <h1>Lab 7: Photo Gallery</h1>
          </div>
          <h2>Favorite Artists</h2>
          {imageButtons.map((button, index) => (
            <button
              key={index}
              onClick={() =>
                handleImgChange(button.src, button.alt, button.caption)
              }
            >
              {button.buttonNum}
            </button>
          ))}
          <div>
            <img src={src} alt={alt} className="gallery" />
            <p className="caption">{caption}</p>
          </div>
        </div>
      </div>
    </React.StrictMode>
  );
}

root.render(<FaveArtists />);

export default FaveArtists;
