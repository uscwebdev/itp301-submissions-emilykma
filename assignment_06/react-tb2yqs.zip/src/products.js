import React from 'react';

export default function Products(prop) {
  return (
    <div id="product">
      <div className="image">
        <img className="height-100" src={prop.src} alt={prop.alt} />
      </div>

      <p>
        <strong>{prop.brand}</strong>
      </p>

      <p>{prop.product}</p>

      <p>${prop.price}</p>
    </div>
  );
}
